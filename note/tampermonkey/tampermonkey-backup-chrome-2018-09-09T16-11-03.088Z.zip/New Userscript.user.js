// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://eow.alc.co.jp/*
// @grant        none
// ==/UserScript==

window.addEventListener('load',
function() {
  document.activeElement.blur();
  this.removeEventListener('load', arguments.callee, false);
},
false);